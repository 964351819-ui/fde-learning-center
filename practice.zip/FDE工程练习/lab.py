"""FDE 零费用练习：数据检查、有效资料过滤与有权限的幂等工单。
使用 Python 标准库，不调用任何外部模型。词匹配只是检索教学基线。
"""
import argparse, json, sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RULES=json.loads((ROOT/'rules.json').read_text())
TICKETS=json.loads((ROOT/'tickets.json').read_text())

def check_data(records):
    seen=set(); errors=[]
    for row in records:
        rid=row.get('id')
        if not rid or rid in seen: errors.append({'id':rid,'issue':'缺失或重复编号'})
        if not row.get('store'): errors.append({'id':rid,'issue':'门店缺失'})
        if not row.get('question'): errors.append({'id':rid,'issue':'问题缺失'})
        seen.add(rid)
    return errors

def retrieve(store, date, question, role='store'):
    """先检查业务与访问范围，再进行极简词匹配；绝不生成无依据答案。"""
    if not store:return {'action':'ask','message':'请提供门店编号'}
    if role!='store':return {'action':'deny','message':'角色不在此练习的允许范围'}
    candidates=[r for r in RULES if r['store']==store and r['from']<=date<=r['to'] and r['visibility']=='store']
    matches=[r for r in candidates if any(word in question for word in r['keywords'])]
    if not matches:return {'action':'handover','message':'没有找到当前有效依据，请运营确认'}
    return {'action':'draft','facts':[r['rule'] for r in matches],'sources':[r['id'] for r in matches], 'human_review':True}

def create_ticket(connection, request_id, store, description, approved=False):
    if not approved: return {'action':'await_approval'}
    if not request_id or not store or not description:raise ValueError('缺少请求编号、门店或描述')
    # 此练习本地 SQLite 保存记录；数据库唯一键负责避免重复。
    connection.execute('CREATE TABLE IF NOT EXISTS tickets (request_id TEXT PRIMARY KEY, store TEXT NOT NULL, description TEXT NOT NULL)')
    connection.execute('INSERT OR IGNORE INTO tickets VALUES (?,?,?)',(request_id,store,description))
    connection.commit()
    row=connection.execute('SELECT request_id,store,description FROM tickets WHERE request_id=?',(request_id,)).fetchone()
    if row[1:]!=(store,description):raise ValueError('同一请求编号不能用于不同内容')
    return {'action':'created_or_existing','request_id':row[0],'store':row[1],'description':row[2]}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('exercise',choices=['data','retrieve','workflow'])
    args=parser.parse_args()
    if args.exercise=='data':result=check_data(TICKETS)
    elif args.exercise=='retrieve':result=retrieve('001','2026-10-08','优惠券能否叠加？')
    else:
        con=sqlite3.connect(':memory:')
        first=create_ticket(con,'demo-001','001','活动问题',True)
        repeat=create_ticket(con,'demo-001','001','活动问题',True)
        result={'first':first,'repeat':repeat,'count':con.execute('SELECT COUNT(*) FROM tickets').fetchone()[0]}
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
