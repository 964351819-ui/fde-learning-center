import sqlite3,unittest
from lab import check_data,retrieve,create_ticket,TICKETS
class Checks(unittest.TestCase):
 def test_data_missing_duplicate(self):
  issues=check_data(TICKETS)
  self.assertTrue(any(r['issue']=='门店缺失' for r in issues))
  self.assertTrue(any(r['issue']=='缺失或重复编号' for r in issues))
 def test_filter_old_store_and_private(self):
  result=retrieve('001','2026-10-08','优惠券能否叠加？')
  self.assertEqual(result['sources'],['promo-001-current'])
 def test_absent_evidence(self):
  self.assertEqual(retrieve('001','2026-10-08','设备怎么修？')['action'],'handover')
 def test_missing_store(self):
  self.assertEqual(retrieve('','2026-10-08','优惠券')['action'],'ask')
 def test_permissions(self):
  self.assertEqual(retrieve('001','2026-10-08','优惠券',role='anonymous')['action'],'deny')
 def test_approval_and_repetition(self):
  con=sqlite3.connect(':memory:')
  self.assertEqual(create_ticket(con,'r1','001','问活动')['action'],'await_approval')
  one=create_ticket(con,'r1','001','问活动',True)
  two=create_ticket(con,'r1','001','问活动',True)
  self.assertEqual(one,two)
  self.assertEqual(con.execute('SELECT COUNT(*) FROM tickets').fetchone()[0],1)
  with self.assertRaises(ValueError):create_ticket(con,'r1','002','不同内容',True)
if __name__=='__main__':unittest.main()
