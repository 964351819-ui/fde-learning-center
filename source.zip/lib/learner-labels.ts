/** Human names for classroom references; storage keys remain stable. */
const names:Record<string,string>={P01:'项目委托说明',R09:'一号门店九月旧活动规则',R10:'一号门店十月活动规则',R20:'二号门店十月活动规则',T01:'优惠叠加咨询',T02:'缺少门店信息的优惠咨询',T03:'退款咨询',E01:'引用旧规则的错误答复',S05:'咨询处理时间记录',TEAM:'岗位分工表',TEST:'第一轮测试记录',INPUT:'示例输入记录',CLASS:'工单分类要求',FLOW:'退款建议处理流程',REQ:'重复请求与超时记录',LOG:'运行记录',COST:'服务成本假设',CAP:'审核时间安排',ADOPT:'试点使用数据',ACCESS:'权限与资料维护要求',CHANGE:'采购部门扩展需求',PLAN:'三十天实施计划'};
export function lessonLabel(id:string){return /^L\d+$/.test(id)?`第${Number(id.slice(1))}课`:id;}
export function readableLabels(value:string):string{
 return value.replace(/文件编号 R\d+，/g,'').replace(/咨询编号 T\d+。/g,'')
 .replace(/\b(?:P01|R09|R10|R20|T01|T02|T03|E01|S05|TEAM|TEST|INPUT|CLASS|FLOW|REQ|LOG|COST|CAP|ADOPT|ACCESS|CHANGE|PLAN)\b/g,key=>names[key])
 .replace(/\bL\d{2}\b/g,lessonLabel)
 .replace(/001\s*(?:门店|店)/g,'一号门店').replace(/002\s*(?:门店|店)/g,'二号门店')
 .replace(/\b001\b/g,'一号门店').replace(/\b002\b/g,'二号门店').replace(/一号门店长/g,'一号门店店长')
 .replace(/版本 v1/g,'第一版').replace(/版本 v2/g,'第二版').replace(/\bv1\b/g,'第一版').replace(/\bv2\b/g,'第二版');
}
