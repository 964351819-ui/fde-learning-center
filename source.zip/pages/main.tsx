import React from 'react';
import {createRoot} from 'react-dom/client';
import LearningCenter from './learning-center';
createRoot(document.getElementById('root')!).render(<LearningCenter/>);
