import {lessons,courseVersion} from '../lib/course';
import {caseLessons} from '../lib/casebook';
const key='fde-learning-progress-v1';
export function readLocal(){const data=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(data))throw Error('学习记录格式异常，请先导出备份。');return data;}
function write(data:any[]){localStorage.setItem(key,JSON.stringify(data));}
export function importProgress(data:any){if(!Array.isArray(data.progress))throw Error('请选择学习记录 JSON 文件。');const existing=readLocal();for(const row of data.progress){if(!caseLessons[row.lesson_id]||typeof row.draft!=='string'||typeof row.answers!=='string'||!['started','submitted','reviewed','needs_revision'].includes(row.status))throw Error('记录格式不正确，未导入。');JSON.parse(row.answers);}const merged=new Map(existing.map((r:any)=>[r.lesson_id,r]));for(const row of data.progress){const old:any=merged.get(row.lesson_id);if(!old||row.updated_at>old.updated_at)merged.set(row.lesson_id,row);}write(Array.from(merged.values()));}
export async function learningFetch(url:string,options?:RequestInit){try{
 if(options?.method!=='POST'){let briefs:any[]=[];try{const response=await fetch('./daily-news.json',{cache:'no-store'});if(response.ok)briefs=[await response.json()];}catch{}return Response.json({progress:readLocal(),briefs,maintenance:{}});}
 const p=JSON.parse(options.body as string);const lesson=lessons.find(l=>l.id===p.lessonId);if(!lesson)throw Error('课次不存在。');if(['confirm','submit'].includes(p.action)&&p.courseVersion!==courseVersion)throw Error('请刷新课程后继续。');
 const rows=readLocal(),old=rows.find((r:any)=>r.lesson_id===p.lessonId);const prev=JSON.parse(old?.answers||'{}'),answers={...prev,...p.answers};answers.confirmedChoice=prev.confirmedChoice;answers.quizVersion=prev.quizVersion;
 if(answers.choice!==prev.choice){delete answers.confirmedChoice;delete answers.quizVersion;}
 const choice=answers.choice;if(p.action==='confirm'){if(!Number.isInteger(choice)||choice<0||choice>=lesson.question.options.length)throw Error('先选一个答案。');answers.confirmedChoice=choice;answers.quizVersion=courseVersion;}
 let status=old?.status||'started',feedback=old?.feedback||'';if(p.draft!==old?.draft&&['reviewed','submitted','needs_revision'].includes(status)){status='started';feedback='';}
 if(p.action==='submit'){if(choice!==lesson.question.correct||answers.confirmedChoice!==choice||answers.quizVersion!==courseVersion)throw Error('请先选对并确认判断题。');if(!Array.isArray(answers.guided)||answers.guided.length!==2||answers.guided.some((v:any)=>typeof v!=='string'||!v.trim()))throw Error('请填写两道练习。');status='submitted';feedback='';answers.submissionVersion=courseVersion;}
 const now=new Date().toISOString(),row={lesson_id:p.lessonId,step:Math.max(0,Math.min(3,Number(p.step)||0)),draft:String(p.draft||'').slice(0,16000),answers:JSON.stringify(answers),status,feedback,completed_at:p.action==='submit'?now:old?.completed_at||null,review_at:old?.review_at||null,updated_at:now};
 write([...rows.filter((r:any)=>r.lesson_id!==p.lessonId),row]);return Response.json({saved:true,status});
 }catch(error){return Response.json({error:error instanceof Error?error.message:'无法保存，请检查浏览器存储权限。'},{status:400});}}
